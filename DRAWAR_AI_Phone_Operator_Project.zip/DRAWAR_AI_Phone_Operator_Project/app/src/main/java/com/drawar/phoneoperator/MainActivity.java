package com.drawar.phoneoperator;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 101, MIC_PERMISSION = 102;
    private TextView status;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tts = new TextToSpeech(this, result -> { if (tts != null) tts.setLanguage(new Locale("ur", "PK")); });
        buildUi();
    }

    private void buildUi() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(28, 36, 28, 28); layout.setGravity(Gravity.CENTER_HORIZONTAL); layout.setBackgroundColor(0xFF10121B);
        TextView title = new TextView(this); title.setText("DRAWAR AI PHONE OPERATOR"); title.setTextColor(0xFFB8A5FF); title.setTextSize(22); title.setGravity(Gravity.CENTER); layout.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView help = new TextView(this); help.setText("\nUrdu / Hinglish voice assistant\nTap the mic and speak a command."); help.setTextColor(0xFFECECF4); help.setTextSize(16); help.setGravity(Gravity.CENTER); layout.addView(help);
        Button mic = button("🎙  Speak Command"); layout.addView(mic, new LinearLayout.LayoutParams(-1, -2)); mic.setOnClickListener(v -> listen());
        status = new TextView(this); status.setText("\nReady. Try: YouTube kholo, WhatsApp kholo, browser kholo."); status.setTextColor(0xFFECECF4); status.setTextSize(16); layout.addView(status, new LinearLayout.LayoutParams(-1, -2));
        Button yt = button("Open YouTube"); layout.addView(yt, new LinearLayout.LayoutParams(-1, -2)); yt.setOnClickListener(v -> openUrl("https://www.youtube.com"));
        Button wa = button("Open WhatsApp"); layout.addView(wa, new LinearLayout.LayoutParams(-1, -2)); wa.setOnClickListener(v -> openWhatsApp());
        ScrollView scroll = new ScrollView(this); scroll.addView(layout); setContentView(scroll);
    }
    private Button button(String text) { Button b = new Button(this); b.setText(text); b.setAllCaps(false); return b; }

    private void listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION); return; }
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK"); intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK"); intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Apna command boliye");
            startActivityForResult(intent, SPEECH_REQUEST);
        } catch (ActivityNotFoundException e) { speak("Is phone par speech recognition service available nahi hai."); status.setText("Speech recognition unavailable. Check Google app and internet."); }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK && data != null) { ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if (results != null && !results.isEmpty()) handleCommand(results.get(0)); }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MIC_PERMISSION && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) listen(); else if (requestCode == MIC_PERMISSION) speak("Microphone permission zaroori hai.");
    }
    private void handleCommand(String raw) {
        String c = raw.toLowerCase(Locale.ROOT); status.setText("You said: " + raw);
        if (c.contains("youtube") || c.contains("یوٹیوب")) { String query = c.replace("youtube", "").replace("search", "").replace("play", "").replace("kholo", "").trim(); if (query.isEmpty() || query.equals("open") || query.equals("chalao")) openUrl("https://www.youtube.com"); else openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(query)); speak("YouTube khol raha hoon."); }
        else if (c.contains("whatsapp") || c.contains("واٹس ایپ")) { openWhatsApp(); speak("WhatsApp khol raha hoon."); }
        else if (c.contains("browser") || c.contains("chrome") || c.contains("internet")) { openUrl("https://www.google.com"); speak("Browser khol raha hoon."); }
        else if (c.contains("setting")) { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); speak("Settings khol raha hoon."); }
        else if (c.contains("call ") || c.startsWith("dial ")) { String digits = raw.replaceAll("[^0-9+]", ""); if (digits.length() >= 7) { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + digits))); speak("Dialer khol diya hai. Call se pehle number check karein."); } else { startActivity(new Intent(Intent.ACTION_DIAL)); speak("Dialer khol diya hai. Number check karke call karein."); } }
        else speak("Yeh command abhi samajh nahi aayi. YouTube, WhatsApp, browser ya settings bol kar try karein.");
    }
    private void openWhatsApp() { Intent launch = getPackageManager().getLaunchIntentForPackage("com.whatsapp"); if (launch != null) startActivity(launch); else openUrl("https://www.whatsapp.com/android"); }
    private void openUrl(String url) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { status.setText("Could not open: " + url); } }
    private void speak(String text) { if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "drawar-response"); }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
